package com.example.springweb.service;

import com.example.springweb.dao.Student;
import com.example.springweb.mapper.Studentmapper;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * @author 业务逻辑层封装sql语句
 */
@Service
public class StuService {
//    @Resource
//    private StuMapper stuMapper;

    private final Studentmapper studentRepository;

    public StuService(Studentmapper studentRepository) {
        this.studentRepository = studentRepository;
    }

    /**
     *获取所有学生列表
     */
    public List<Student> getUserList() {
        List<Student> list = StreamSupport.stream(studentRepository.findAll().spliterator(),false).collect(Collectors.toList());
        return list;
    }

    /**
     *插入新学生
     */
    public void InsertStu(Map<String, String> params){
        ObjectMapper objectMapper = new ObjectMapper();
        Student student = objectMapper.convertValue(params, Student.class);
        studentRepository.save(student);
    }

    /**
     * 获得一个学生信息
     */
    public Student getOne(String id){
        Student result = studentRepository.findById(id).get();//stuMapper.SelectById(id);
        System.out.println("getOne:"+result);
        if (result==null)
        {
            result=new Student();
            //索引为空的时候，返回null，需要这时候对其getId,getName就会出错。
        }
        System.out.println(result.toString());
        return result;
    }

    /**
     * 更新学生信息
     */
    public void UpdateByID(Map<String, String> params){
        String id = params.get("id");

        Student temp = studentRepository.findById(id).get();
        if(params.get("name")!=null) {
            temp.setName(params.get("name"));
        }
        if(params.get("sex")!=null) {
            temp.setSex(params.get("sex"));
        }
        if(params.get("birth")!=null) {
            temp.setBirth(params.get("birth"));
        }
        if(params.get("nativePlace")!=null) {
            temp.setNativePlace(params.get("nativePlace"));
        }
        if(params.get("department")!=null) {
            temp.setDepartment(params.get("department"));
        }

        studentRepository.save(temp);
    }

    /**
     *删除学生信息
     */
    public void DeleteByID(String id){
//        stuMapper.DeleteById(id);
//        System.out.println("AfterDelete:"+stuMapper.SelectById(id));
        studentRepository.deleteById(id);
    }

    public boolean Update(Student student)
    {
        if(!studentRepository.findById(student.getId()).isPresent()) {
            return false;
        }
        studentRepository.save(student);
        return true;
    }
    public boolean Add(Student student)
    {
        if(!studentRepository.findById(student.getId()).isPresent()) {
            return false;
        }
        studentRepository.deleteById(student.getId());
        studentRepository.save(student);
        return true;
    }
    public boolean Delete(Student student)
    {
        if(!studentRepository.findById(student.getId()).isPresent())
        {
            return false;
        }
        studentRepository.delete(student);
        return true;
    }
}
