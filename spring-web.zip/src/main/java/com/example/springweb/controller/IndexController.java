package com.example.springweb.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author machenike
 */
@Controller
public class IndexController {
    @RequestMapping("/")
    public String hello(Model model) {
        return "index";
    }
}
