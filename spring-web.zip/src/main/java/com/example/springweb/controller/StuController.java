package com.example.springweb.controller;

import com.example.springweb.dao.Student;
import com.example.springweb.service.SearchService;
import com.example.springweb.service.StuService;

import org.apache.ibatis.annotations.Delete;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 控制器
 */
@RestController
public class StuController {
    @Autowired
    StuService stuService;


    @GetMapping(value = "/generateId")
    @ResponseBody
    public String GenerateID(HttpServletResponse response)
    {
        List<Student> list = stuService.getUserList();
        int i;
        for(i = 0; i < list.size(); i++)
        {
            if(i != Integer.parseInt(list.get(i).getId().toString())) {
                break;
            }
        }
        String id = ""+i;
        Map<String, String> params = new HashMap<>();
        params.put("id",id);
        params.put("name","");
        params.put("sex","女");
        params.put("birth","");
        params.put("nativePlace","");
        params.put("department","");
        stuService.InsertStu(params);
//        System.out.println("in generateid");
        response.setHeader("Access-Control-Allow-Origin", "*");
        return id;
    }

    @GetMapping(value = "/delete", params = {"id"})
    @ResponseBody
    public String Delete(@RequestParam(value = "id")String id,HttpServletResponse response)
    {
        System.out.println(id);
        stuService.DeleteByID(id);
        response.setHeader("Access-Control-Allow-Origin", "*");
        return "";
    }

    @GetMapping(value = "/update", params = {"id","name", "sex", "birth", "nativePlace", "department"})
    @ResponseBody
    public String Update(
                        @RequestParam(value = "id")String id,
                        @RequestParam(value = "name")String name,
                        @RequestParam(value = "sex")String sex,
                        @RequestParam(value = "birth")String birth,
                        @RequestParam(value = "nativePlace")String nativePlace,
                        @RequestParam(value = "department")String department,
                        HttpServletResponse response
                         )
    {
        Map<String, String> params = new HashMap<>();
        params.put("id",id);
        params.put("name",name);
        params.put("sex",sex);
        params.put("birth",birth);
        params.put("nativePlace",nativePlace);
        params.put("department",department);
        stuService.UpdateByID(params);
        response.setHeader("Access-Control-Allow-Origin", "*");
        return "";
    }

    @GetMapping(value = "/search",params={"condition", "key"})
    @ResponseBody
    public String Search(
                        @RequestParam(value = "condition")String condition,
                        @RequestParam(value = "key")String key,
                        HttpServletResponse response
                        )
    {
        SearchService ss = new SearchService();
//        System.out.println("c:"+ condition + " k:" + key);
        response.setHeader("Access-Control-Allow-Origin", "*");
        return ss.search(condition, key, stuService.getUserList());

    }

    @PostMapping(value = "/student")
    public ResponseEntity<?> newStudent(@RequestBody Student student, HttpServletResponse response)
    {
        System.out.println("in post: " + student);
//        student.setId("1");
        if(stuService.Add(student)) {
            //response.setHeader("Access-Control-Allow-Origin", "*");
            return ResponseEntity.ok(student);
        }
        else {
            response.setHeader("Access-Control-Allow-Origin", "*");
            return ResponseEntity.badRequest().body("Create" + student + "error!");
        }
    }

    @PutMapping(value = "/student/{id}")
    public ResponseEntity<?> updateStudent(@RequestBody Student student, @PathVariable String id,HttpServletResponse response)
    {
        System.out.println("in put: " + student);
        Student s = student;
        s.setId(id);
       if( stuService.Update(s))
       {
           response.setHeader("Access-Control-Allow-Origin", "*");
           return ResponseEntity.ok(s);
       }
       else
       {
           response.setHeader("Access-Control-Allow-Origin", "*");
           return ResponseEntity.notFound().build();
       }
    }

    @DeleteMapping(value = "/student/{id}")
    public ResponseEntity<?> deleteStudent(@RequestBody Student student, @PathVariable String id,HttpServletResponse response)
    {
        System.out.println("in delete: " + student);
        Student s = student;
        s.setId(id);
        if(stuService.Delete(s))
        {
            response.setHeader("Access-Control-Allow-Origin", "*");
            return ResponseEntity.ok(s);
        }
        else
        {
            response.setHeader("Access-Control-Allow-Origin", "*");
            return ResponseEntity.notFound().build();
        }
    }
}
