package com.example.springweb.mapper;

import com.example.springweb.dao.Student;
import org.springframework.data.repository.CrudRepository;

public interface Studentmapper extends CrudRepository<Student, String> { }
