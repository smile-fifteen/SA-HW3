<template>
    <div id="second">
        <button id="add" onclick="add()">新增</button>
        <button id="del" onclick="del()">删除</button>
    </div>
</template>

<script>
    export default
    {
        name:"second"
    }
</script>