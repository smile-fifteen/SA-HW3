<template>
    <div id="top">
        <div class="headerLine">————————————————</div><br>
        <div id="header">学生信息管理系统</div><br>
        <div class="headerLine">————————————————</div><br>
    </div>
</template>

<script>
    export default
    {
        name:"top"
    }
</script>
