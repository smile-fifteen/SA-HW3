<template>
    <div id="main">
        <table cellspacing="0px" id="myTable">
            <thead>
            <tr>
                <th class="col1"><input type="checkbox" onclick="checkAll(this)"/></th>
                <th class="col2">学号</th>
                <th class="col3">姓名</th>
                <th class="col4">性别</th>
                <th class="col5">出生年月</th>
                <th class="col6">籍贯</th>
                <th class="col7">院系</th>
                <th class="col8">操作</th>

            </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div>
</template>

<script>
    export default
    {
        name:"mainT"
    }
</script>