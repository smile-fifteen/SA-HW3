<template>
    <div id="third">
        <input type = 'checkbox' id = 'cid' name = 'condition'>学号
        <input type = 'checkbox' id = 'cname' name = 'condition'>姓名
        <input type = 'checkbox' id = 'csex' name = 'condition'>性别
        <input type = 'checkbox' id = 'cbirth' name = 'condition'>出生日期
        <input type = 'checkbox' id = 'cnative_place' name = 'condition'>籍贯
        <input type = 'checkbox' id = 'cdepartment' name = 'condition'>院系

        <input id="key" type="text" placeholder="请输入数据包含的字符..." style="height: 20px;width: 200px">
        <button id="search" onclick="search()">查询</button>
        <button id="refresh" onclick="initial()">刷新</button>
    </div>
</template>

<script>
    export default
    {
        name:"third"
    }
</script>