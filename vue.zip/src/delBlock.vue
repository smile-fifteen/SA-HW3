<template>
    <div id="delBlock">
        <div id="delHeader">待删除的学生信息</div>
        <div id="delMain">
            <p>您确定删除以下同学的信息</p>
            <p id="delMessage"></p>
        </div>
        <div style="text-align: right; height: 35px; padding-top: 5px; padding-right: 20px">
            <button id="confirm" onclick="confirm()">确认</button>
            <button id="delCancel" onclick="delCancel()">取消</button>
        </div>
    </div>
</template>

<script>
    export default
    {
        name:"delBlock"
    }
</script>