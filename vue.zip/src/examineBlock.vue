<template>
    <div id="examineBlock">
        <div id="examineHeader">查看学生信息</div>
        <div id="examineMain">
            <table id="examineMessageTable">
                <tr>
                    <td class="examineTableTd1">学号</td>
                    <td class="examineTableTd2"><input type="text" id="id_3" readonly="readonly" /></td>
                </tr>
                <tr>
                    <td class="examineTableTd1">姓名</td>
                    <td class="examineTableTd2"><input type="text" id="name_3" readonly="readonly" /></td>
                </tr>
                <tr>
                    <td class="examineTableTd1">性别</td>
                    <td class="examineTableTd2">
                        <input type="radio" id="girl_3" name="sex_3" style="width: 30px" disabled/> 女
                        <input type="radio" id="boy_3" name="sex_3" style="width: 30px" disabled/> 男
                    </td>
                </tr>
                <tr>
                    <td class="examineTableTd1">出生年月</td>
                    <td class="examineTableTd2"><input type="text" id="birth_3" readonly="readonly" /></td>
                </tr>
                <tr>
                    <td class="examineTableTd1">籍贯</td>
                    <td class="examineTableTd2"><input type="text" id="native_place_3" readonly="readonly" /></td>
                </tr>
                <tr>
                    <td class="examineTableTd1">院系</td>
                    <td class="examineTableTd2"><input type="text" id="department_3" readonly="readonly" /></td>
                </tr>

            </table>
        </div>
        <div style="text-align: right; height: 35px; padding-top: 5px; padding-right: 20px">
            <button id="examineCancel" onclick="examineCancel()">取消</button>
        </div>
    </div>
</template>

<script>
    export default
    {
        name:"examineBlock"
    }
</script>