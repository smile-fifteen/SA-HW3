<template>
  <div id="total">
    <top /><br><br>

    <second />

    <third />

    <mainT />

    <final />

  </div>
</template>

<script>

import top from "./components/top.vue"
import second from "./components/second.vue";
import Third from "./components/third";
import final from "./components/final.vue";
import mainT from "./components/main.vue";

export default {
  name: "Total",
  components: {
    Third,
    top,
    second,
    final,
    mainT
  }

};
</script>

<style>

</style>
