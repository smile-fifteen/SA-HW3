<template>
    <div id="addBlock">
        <div id="addHeader">新增学生信息</div>
        <div id="addMain">
            <table id="addMessageTable">
                <tr>
                    <td class="addTableTd1">学号</td>
                    <td class="addTableTd2"><input type="text" id="id_1"  disabled/></td>
                </tr>
                <tr>
                    <td class="addTableTd1">姓名</td>
                    <td class="addTableTd2"><input type="text" id="name_1" /></td>
                </tr>
                <tr>
                    <td class="addTableTd1">性别</td>
                    <td class="addTableTd2">
                        <input type="radio" id="girl" name="sex_1" style="width: 30px" checked/> 女
                        <input type="radio" id="boy" name="sex_1" style="width: 30px"/> 男
                    </td>
                </tr>
                <tr>
                    <td class="addTableTd1">出生年月</td>
                    <td class="addTableTd2"><input type="date" id="birth_1" /></td>
                </tr>
                <tr>
                    <td class="addTableTd1">籍贯</td>
                    <td class="addTableTd2"><input type="text" id="native_place_1" /></td>
                </tr>
                <tr>
                    <td class="addTableTd1">院系</td>
                    <td class="addTableTd2"><input type="text" id="department_1" /></td>
                </tr>

            </table>
        </div>
        <div style="text-align: right; height: 35px; padding-top: 5px; padding-right: 20px">
            <button id="submit" onclick="sumbit()">提交</button>
            <button id="addCancel" onclick="addCancel()">取消</button>
        </div>
    </div>
</template>
<script>
    export default
    {
        name: "addBlock"
    }
</script>