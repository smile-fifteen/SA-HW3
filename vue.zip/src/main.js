import Vue from 'vue'
import Total from './total.vue'
import addBlock from "./addBlock"
import updateBlock from "./updateBlock";
import examineBlock from "./examineBlock";
import delBlock from "./delBlock";

Vue.config.productionTip = false

new Vue({
  render: h => h(Total),
}).$mount('#total')
new Vue({
  render: h =>h(addBlock),
}).$mount('#addBlock')
new Vue({
  render: h =>h(updateBlock),
}).$mount('#updateBlock')

new Vue({
  render: h =>h(examineBlock),
}).$mount('#examineBlock')
new Vue({
  render: h =>h(delBlock),
}).$mount('#delBlock')
