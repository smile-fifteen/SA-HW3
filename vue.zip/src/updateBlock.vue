<template>
    <div id="updateBlock">
        <div id="updateHeader">修改学生信息</div>
        <div id="updateMain">
            <table id="updateMessageTable">
                <tr>
                    <td class="addTableTd1">学号</td>
                    <td class="addTableTd2"><input type="text" id="id_2" disabled/></td>
                </tr>
                <tr>
                    <td class="addTableTd1">姓名</td>
                    <td class="addTableTd2"><input type="text" id="name_2" /></td>
                </tr>
                <tr>
                    <td class="addTableTd1">性别</td>
                    <td class="addTableTd2">
                        <input type="radio" id="girl_2" name="sex_2" style="width: 30px" checked/> 女
                        <input type="radio" id="boy_2" name="sex_2" style="width: 30px"/> 男
                    </td>
                </tr>
                <tr>
                    <td class="addTableTd1">出生年月</td>
                    <td class="addTableTd2"><input type="date" id="birth_2" /></td>
                </tr>
                <tr>
                    <td class="addTableTd1">籍贯</td>
                    <td class="addTableTd2"><input type="text" id="native_place_2" /></td>
                </tr>
                <tr>
                    <td class="addTableTd1">院系</td>
                    <td class="addTableTd2"><input type="text" id="department_2" /></td>
                </tr>

            </table>
        </div>
        <div style="text-align: right; height: 35px; padding-top: 5px; padding-right: 20px">
            <button id="preservation" onclick="preservation()">保存</button>
            <button id="updateCancel" onclick="updateCancel()">取消</button>
        </div>
    </div>
</template>

<script>
    export default
    {
        name:"updateBlock"
    }
</script>