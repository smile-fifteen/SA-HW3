// 全选
function checkAll(obj){
    var status = obj.checked;
    var items = document.getElementsByName('item');
    var pageNum = document.getElementById('pageNum').innerText;
    pageNum = parseInt(pageNum);
    for (var i=(pageNum-1)*10; i<pageNum*10; i++) {
        items[i].checked=status;
    }
}

// 删除按钮
function del() {
    // 打开删除框架
    document.getElementById('delBlock').style.display = 'block';
    document.getElementById('totalBackground').style.display = 'block';

    var items = document.getElementsByName('item');
    var message = [];
    for(var j=0;j<items.length;j++){
        if(items[j].checked) //如果item被选中
        {
            var m = items[j].parentNode.parentNode.cells[1].innerText + " " + items[j].parentNode.parentNode.cells[2].innerText+"\n";
            message.push(m);
        }
    }

    var delNode = document.getElementById('delMessage');
    delNode.innerText = message.join('\t');
}

// 确认按钮
function confirm() {
    // 关闭删除框架
    document.getElementById('delBlock').style.display = 'none';
    document.getElementById('totalBackground').style.display = 'none';

    var items = document.getElementsByName('item');
    var items_num = 0;
    for(var j=0;j<items.length;j++){
        if(items[j].checked)//如果item被选中
        {
            var id = items[j].parentNode.parentNode.cells[1].innerText;
            var x = items[j].parentNode.parentNode;
            var xmlhttp = new XMLHttpRequest();
            var json = {
                "id":x.cells[1].innerText,
                "name":x.cells[2].innerText,
                "sex":x.cells[3].innerText,
                "birth":x.cells[4].innerText,
                "nativePlace":x.cells[5].innerText,
                "department":x.cells[6].innerText
            } ;
            xmlhttp.open("DELETE", "http://localhost:8081/student/"+id,false);
            xmlhttp.setRequestHeader("Content-type","application/json");
            xmlhttp.send(JSON.stringify(json));
            //alert(xmlhttp.status + "\n" + xmlhttp.responseText);
            // xmlhttp.open("GET", "/delete?id="+id, false);
            // xmlhttp.send();
            // var json = {
            //         id: x.cells[1].innerText, name: x.cells[2].innerText,
            //         sex:x.cells[3].innerText, birth:x.cells[4].innerText,
            //         nativePlace:x.cells[5].innerText,department:x.cells[6].innerText
            //     };
            // $.ajax(
            //     {
            //         url:"http://localhost:8888/student/"+id,
            //         type: "DELETE",
            //         contentType:"application/json",
            //         data:JSON.stringify(json),
            //         dataType:"json",
            //         success:function (result) {
            //             alert("Rest Delete data: " + result);
            //         }
            //     }
            //     );
            items_num += 1;
            items[j].parentNode.parentNode.remove();
            j--;
        }
    }


    var iTable = document.getElementById('myTable');
    var iTrs = iTable.getElementsByTagName('tr');
    for (var i=1; i<iTrs.length; i++) {
        if (i % 2 != 0)
            iTrs[i].className = 'mainTbodyTr1';
        else
            iTrs[i].className = 'mainTbodyTr2';
        // var sort = iTrs[i].getElementsByTagName('td')[1];
        // sort.innerText = i;
    }

    var nums = iTrs.length - 1;
    if(nums < 10)
        document.getElementById('nums').innerText = nums;
    else
        document.getElementById('nums').innerText = "10";
    nums = parseInt(nums);
    var pageSum = Math.ceil(nums / 10);
    var pageNum = document.getElementById('pageNum').innerText;
    pageNum = parseInt(pageNum);

    if (pageNum <= pageSum) {
        for (var i=(pageNum-1)*10+1; i<pageNum*10+1; i++) {
            iTable.rows[i].style.display = 'table-row';
        }
        for (var i=1; i<(pageNum-1)*10+1; i++) {
            iTable.rows[i].style.display = 'none';
        }
        for (var i=pageNum*10+1; i<nums+1; i++) {
            iTable.rows[i].style.display = 'none';
        }
    }
    if (pageNum > pageSum) {
        for (var i=(pageNum-2)*10+1; i<nums+1; i++) {
            iTable.rows[i].style.display = 'table-row';
        }
        for (var i=1; i<(pageNum-2)*10+1; i++) {
            iTable.rows[i].style.display = 'none';
        }
        document.getElementById('pageNum').innerText = pageNum - 1;
    }

}

// 删除中的取消按钮
function delCancel() {
    // 关闭删除框架
    document.getElementById('delBlock').style.display = 'none';
    document.getElementById('totalBackground').style.display = 'none';
}
